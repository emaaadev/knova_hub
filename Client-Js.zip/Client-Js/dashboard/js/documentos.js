// Primera integración del Ticket #5: consulta y búsqueda de documentos.
// Todas las consultas pasan por App.api, que adjunta el JWT de la sesión.
const sesionDocumentos = App.setupShell();

if (sesionDocumentos) {
    iniciarDocumentos();
}

async function iniciarDocumentos() {
    const tipoInicial = new URLSearchParams(window.location.search).get("tipo");
    if (tipoInicial === "wiki") {
        document.getElementById("filtrar-tipo").value = "2";
    }
    document.getElementById("buscar-documentos").addEventListener("input", filtrarDocumentos);
    document.getElementById("filtrar-tipo").addEventListener("change", filtrarDocumentos);
    document.getElementById("btn-recargar").addEventListener("click", cargarDocumentos);
    document.getElementById("cerrar-detalle").addEventListener("click", () => {
        document.getElementById("detalle-documento").hidden = true;
    });
    document.getElementById("cuerpo-documentos").addEventListener("click", async (evento) => {
        const boton = evento.target.closest("button[data-documento]");
        if (boton) await verDocumento(Number(boton.dataset.documento));
    });
    await cargarDocumentos();
}

let documentosDisponibles = [];
const tiposDocumento = { 1: "Documento", 2: "Wiki", 3: "Minuta" };

async function cargarDocumentos() {
    const error = document.getElementById("error-documentos");
    const subtitulo = document.getElementById("list-subtitle");
    error.hidden = true;
    subtitulo.textContent = "Cargando documentos…";
    try {
        const respuesta = await App.api("/api/documents");
        // La API puede devolver un arreglo directamente o una colección paginada.
        const lista = Array.isArray(respuesta) ? respuesta : respuesta?.items;
        if (!Array.isArray(lista)) throw new Error("La API devolvió un formato de listado inesperado.");
        documentosDisponibles = lista;
        filtrarDocumentos();
    } catch (e) {
        documentosDisponibles = [];
        filtrarDocumentos();
        subtitulo.textContent = "No se pudieron cargar los documentos.";
        error.textContent = e.message || "Error al consultar la API.";
        error.hidden = false;
    }
}

function filtrarDocumentos() {
    const texto = document.getElementById("buscar-documentos").value.trim().toLocaleLowerCase();
    const tipo = document.getElementById("filtrar-tipo").value;
    const filtrados = documentosDisponibles.filter((d) => {
        const contenido = [d.title, d.description, d.categoryName].join(" ").toLocaleLowerCase();
        return contenido.includes(texto) && (!tipo || String(d.type) === tipo);
    });
    document.getElementById("list-subtitle").textContent =
        `${filtrados.length} documento(s) visibles de ${documentosDisponibles.length}.`;
    document.getElementById("vacio-documentos").hidden = filtrados.length !== 0;
    document.getElementById("cuerpo-documentos").innerHTML = filtrados.map((d) => `
        <tr>
            <td>${App.esc(d.title)}</td>
            <td>${App.esc(tiposDocumento[d.type] || "Desconocido")}</td>
            <td>${d.visibility === 1 ? "General" : "Departamento"}</td>
            <td>${App.esc(d.categoryName || "Sin categoría")}</td>
            <td>${App.esc(d.authorName || "—")}</td>
            <td><button class="btn btn-sm" type="button" data-documento="${Number(d.id)}">Ver</button></td>
        </tr>`).join("");
}

async function verDocumento(id) {
    const error = document.getElementById("error-documentos");
    error.hidden = true;
    try {
        const d = await App.api(`/api/documents/${id}`);
        document.getElementById("detalle-titulo").textContent = d.title || "Sin título";
        document.getElementById("detalle-descripcion").textContent = d.description || "";
        document.getElementById("detalle-metadata").textContent =
            `${tiposDocumento[d.type] || "Contenido"} · ${d.visibility === 1 ? "General" : "Departamento"}` +
            ` · ${d.categoryName || "Sin categoría"}` + (d.departmentName ? ` · ${d.departmentName}` : "");
        document.getElementById("detalle-contenido").textContent = d.content || "Sin contenido de texto.";
        document.getElementById("detalle-archivo").textContent = d.hasFile
            ? `Archivo adjunto: ${d.originalFileName || "Archivo"}. La descarga se integrará en el siguiente paso.`
            : "Sin archivo adjunto.";
        document.getElementById("detalle-documento").hidden = false;
        document.getElementById("detalle-documento").scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (e) {
        error.textContent = e.message || "No se pudo consultar el documento.";
        error.hidden = false;
    }
}
