// Botón compartido para copiar la contraseña temporal sin cerrar la tarjeta.
function configurarCopiaContrasena() {
    const boton = document.getElementById("btn-copy-temp");
    const texto = document.getElementById("temp-password");
    if (!boton || !texto) return;

    const icono = boton.querySelector(".temp-copy-icon");
    const etiqueta = boton.querySelector(".temp-copy-label");
    const iconoOriginal = icono.innerHTML;
    let temporizador;

    function mostrarEstado(estado, mensaje, htmlIcono, descripcion) {
        boton.dataset.state = estado;
        etiqueta.textContent = mensaje;
        icono.innerHTML = htmlIcono;
        boton.title = descripcion;
        boton.setAttribute("aria-label", descripcion);
    }

    boton.addEventListener("click", async (evento) => {
        evento.preventDefault();
        evento.stopPropagation();
        clearTimeout(temporizador);
        try {
            if (!navigator.clipboard?.writeText) {
                throw new Error("Portapapeles no disponible");
            }
            // Elimina únicamente posibles espacios exteriores, conservando el contenido interno.
            await navigator.clipboard.writeText(texto.textContent.trim());
            mostrarEstado("copied", "Copiado", "✓", "Contraseña copiada");
        } catch (error) {
            console.warn("No se pudo copiar la contraseña temporal.", error);
            mostrarEstado("error", "No se pudo copiar", "!", "No se pudo copiar. Selecciona la contraseña manualmente.");
        }
        temporizador = setTimeout(() => {
            mostrarEstado("idle", "Copiar", iconoOriginal, "Copiar contraseña");
        }, 2000);
    });
}
